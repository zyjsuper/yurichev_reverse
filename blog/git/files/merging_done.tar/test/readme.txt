this is readme file

I'll add some very cool feature A in this branch!

feature B added!

